from django.shortcuts import render, redirect
from django.http import HttpResponse
import datetime
from myapp.models import member, hstate, order, wlmachin, flmachin, addpur, store, lock, mode, report, bag, delivery, wmachineinfo, fmachineinfo, lockerinfo
from django.http import Http404
from django.contrib import auth
# from django.shortcuts import get_object_or_404, get_list_or_404 # 快捷函数

# Create your views here.

def privacy_policy(request):
    return render(request, 'page/privacypolicy.html', locals())


def card(request):
    auth = request.POST['auth']
    userid = "1"
    user = member.objects.get(MEMID = userid)

    if user != None:
        member.objects.filter(MEMID = userid).update(AUTHORIZATION = auth)
    
    user1 = member.objects.filter(MEMID = userid).values()
    cardinfo = []

    if user1[0]['CARD1'] != "無":
        cardinfo.append(user1[0]['CARD1'])
    if user1[0]['CARD2'] != "無":
        cardinfo.append(user1[0]['CARD2'])
    if user1[0]['CARD3'] != "無":
        cardinfo.append(user1[0]['CARD3'])
    if user1[0]['CARD4'] != "無":
        cardinfo.append(user1[0]['CARD4'])
    if user1[0]['CARD5'] != "無":
        cardinfo.append(user1[0]['CARD5'])

    return render(request, 'page/payment.html', locals())


def add_card(request):
    cardnum1 = request.POST['cardnum1']
    cardnum2 = request.POST['cardnum2']
    cardnum3 = request.POST['cardnum3']
    cardnum4 = request.POST['cardnum4']
    cardnum = cardnum1+cardnum2+cardnum3+cardnum4
    
    userid = "1"
    user = member.objects.filter(MEMID = userid).values()
    if user[0]['CARD1'] == "無":
        member.objects.filter(MEMID = userid).update(CARD1 = cardnum)
    else:
        if user[0]['CARD2'] == "無":
            member.objects.filter(MEMID = userid).update(CARD2 = cardnum)
        else:
            if user[0]['CARD3'] == "無":
                member.objects.filter(MEMID = userid).update(CARD3 = cardnum)
            else:
                if user[0]['CARD4'] == "無":
                    member.objects.filter(MEMID = userid).update(CARD4 = cardnum)
                else:
                    member.objects.filter(MEMID = userid).update(CARD5 = cardnum)
    
    return redirect('/index/', locals())

def card1(request):
    userid = "1"
    user1 = member.objects.filter(MEMID = userid).values()
    cardinfo = []

    if user1[0]['CARD1'] != "無":
        cardinfo.append(user1[0]['CARD1'])
    if user1[0]['CARD2'] != "無":
        cardinfo.append(user1[0]['CARD2'])
    if user1[0]['CARD3'] != "無":
        cardinfo.append(user1[0]['CARD3'])
    if user1[0]['CARD4'] != "無":
        cardinfo.append(user1[0]['CARD4'])
    if user1[0]['CARD5'] != "無":
        cardinfo.append(user1[0]['CARD5'])

    return render(request, 'page/payment1.html', locals())

def index(request):
    return render(request, 'index.html', locals())

def laundry(request):
    return render(request, 'page/laundry.html', locals())

def purchase(request):
    userid = "1"
    washing = request.POST['washing']
    drying = request.POST['drying']
    fold = request.POST['fold']
    give = request.POST['give']
    collar = request.POST['collar']

    return render(request, 'page/purchase.html', locals())

def order_confirmation(request):
    userid = "1"   #使用者編號
    washing = request.POST['washing']   #洗滌模式
    drying = request.POST['drying']   #乾燥模式
    fold1 = request.POST['fold']   #折衣模式
    give = request.POST['give']   #送洗方式
    collar = request.POST['collar']   #領取方式

    pname1 = request.POST['pname1']
    size1 = request.POST['size1']
    color1 = request.POST['color1']
    quantity1 = int(request.POST['quantity1'])
    pmoney1 = 0

    pname2 = request.POST['pname2']
    size2 = request.POST['size2']
    color2 = request.POST['color2']
    quantity2 = int(request.POST['quantity2'])
    pmoney2 = 0

    pname3 = request.POST['pname3']
    size3 = request.POST['size3']
    color3 = request.POST['color3']
    quantity3 = int(request.POST['quantity3'])
    pmoney3 = 0

    allpname = "無"   #加購商品詳細資料

    wash = mode.objects.filter(MODE = washing).values()
    dry = mode.objects.filter(MODE = drying).values()
    fold = mode.objects.filter(MODE = fold1).values()

    wmoney = wash[0]['MONEY']
    wtax = wash[0]['TAX']
    wpoints = wash[0]['POINTS']
    wtime = int(wash[0]['TIME'])

    dmoney = dry[0]['MONEY']
    dtax = dry[0]['TAX']
    dpoints = dry[0]['POINTS']
    dtime = int(dry[0]['TIME'])

    fmoney = fold[0]['MONEY']
    ftax = fold[0]['TAX']
    fpoints = fold[0]['POINTS']
    ftime = int(fold[0]['TIME'])

    if quantity1 == 0:
        pmoney1 = 0
    else:
        adp1 = addpur.objects.filter(APNAME = pname1, APSIZE = size1, APCOLOR = color1).values()
        pmoney1 = int(adp1[0]['APPRICE'])*quantity1
        allpname = ""
        allpname += color1+pname1+size1+"  x"+str(quantity1)+"\n"

    if quantity2 == 0:
        pmoney2 = 0
    else:
        adp2 = addpur.objects.filter(APNAME = pname2, APSIZE = size2, APCOLOR = color2).values()
        pmoney2 = int(adp2[0]['APPRICE'])*quantity2
        allpname += color2+pname2+size2+"  x"+str(quantity2)+"\n"

    if quantity3 == 0:
        pmoney3 = 0
    else:
        adp3 = addpur.objects.filter(APNAME = pname3, APSIZE = size3, APCOLOR = color3).values()
        pmoney3 = int(adp3[0]['APPRICE'])*quantity3
        allpname += color3+pname3+size3+"  x"+str(quantity3)

    totalmoney = 50+wmoney+dmoney+fmoney+wtax+dtax+ftax+pmoney1+pmoney2+pmoney3   #消費總金額
    totalpoint = 20+wpoints+dpoints+fpoints   #獲得的點數
    totaltime = wtime+dtime+ftime   #處理衣物時長
    totaltax = wtax+dtax+ftax   #花費的碳稅

    needtime = float((totaltime+120)/60)

    loc_dt = datetime.datetime.now()
    time_del = datetime.timedelta(hours = needtime) 
    new_dt = loc_dt + time_del 
    datetime_format = new_dt.strftime("%Y-%m-%d %H:%M")   #預計完成的時間


    datechose = []
    for i in range(1, 13):
        time_del1 = datetime.timedelta(hours = i*2) 
        new_dt1 = new_dt+time_del1
        datetime_format1 = new_dt1.strftime("%Y-%m-%d %H:%M")
        datechose.append(str(datetime_format1))


    return render(request, 'page/order_confirmation.html', locals())

def order_sent(request):   #目前使用者編號、app編號和店舖編號都是寫死的
    washing = request.POST['washing']   #洗滌模式
    drying = request.POST['drying']   #乾燥模式
    fold1 = request.POST['fold1']   #摺衣模式
    give = request.POST['give']   #送洗方式
    collar = request.POST['collar']   #領取方式
    allpname = request.POST['allpname']   #加購商品
    totalmoney = request.POST['totalmoney']   #消費總金額
    totalpoint = request.POST['totalpoint']   #獲得的點數
    totaltime = request.POST['totaltime']   #處理衣物時長
    totaltax = request.POST['totaltax']   #花費的碳稅
    needtime = float(request.POST['needtime'])

    loc_dt = datetime.datetime.now()
    time_del = datetime.timedelta(hours = needtime) 
    new_dt = loc_dt + time_del 
    datetime_format = new_dt.strftime("%Y-%m-%d %H:%M")   #預計完成的時間
    cldate = request.POST['cldate']   #領取時間
    userid = "1"   #使用者編號
    appid = "5"   #app編號
    shopid = "S000001"   #店鋪編號
    loc_dt = datetime.datetime.now()
    cdate = loc_dt.strftime("%Y-%m-%d %H:%M")   #成立時間

    wmlist = wmachineinfo.objects.filter(STATE = "未使用").values()
    fmlist = fmachineinfo.objects.filter(STATE = "未使用").values()
    lklist = lockerinfo.objects.filter(STATE = "未使用").values()
    bglist = bag.objects.filter(STATE = "未租借").values()
    usewm = wmlist[0]['WMID']   #洗烘衣機編號
    usefm = fmlist[0]['FMID']   #摺衣機編號
    uselk = lklist[0]['LOCKID']   #鎖櫃編號
    usebg = bglist[0]['BID']   #洗衣袋編號
    bag.objects.filter(BID = usebg).update(STATE = "已租借")
    wmachineinfo.objects.filter(WMID = usewm).update(STATE = "已使用")
    fmachineinfo.objects.filter(FMID = usefm).update(STATE = "已使用")
    lockerinfo.objects.filter(LOCKID = uselk).update(STATE = "已使用")

    hstate.objects.create(
        MEMID1 = userid, 
        APPID1 = appid, 
        C_AMOUNT1 = totaltax, 
        GPOINT1 = totalpoint, 
        AMOUNT1 = totalmoney, 
        CDATE1 = cdate, 
        WMODE1 = washing,
        LMODE1 = drying,
        FMODE1 = fold1,
        GIVE1 = give,
        COLLAR1 = collar,
        ADDITION1 = allpname,
        HDATE1 = totaltime,
        SHOPID1 = shopid,
        WMID1 = usewm,
        FMID1 = usefm,
        LOCKID1 = uselk,
        BAGID1 = usebg,
        PFTIME1 = datetime_format,
        CLTIME1 = cldate,
        CLOTH1  = "處理中",
        COLSTATE1 = "尚未能領取",
        PAYSTATE1 = "未付款"
    )

    haveorder = hstate.objects.filter(MEMID1 = userid).values()
    for data in haveorder:
        orderidmark = str(data['ORDID1'])
        js1 = "#QR"+str(orderidmark) #  #QR1
        js2 = "#QR_show"+str(orderidmark)   #  #QR_show1
        js3 = "#close"+str(orderidmark)   #  #close1
        js4 = "QR"+str(orderidmark)   #  QR1
        js5 = "QR_show"+str(orderidmark)   #  QR_show1
        js6 = "close"+str(orderidmark)   #  close1
        js7 = "btn"+str(orderidmark)   #   btn1
        hstate.objects.filter(MEMID1 = userid, ORDID1 = orderidmark).update(JS1 = js1, JS2 = js2, JS3 = js3, JS4 = js4, JS5 = js5, JS6 = js6, JS7 = js7)
    


    newestid = orderidmark
    lock.objects.create(LOCKID = uselk, ORDID = newestid, INDATE = datetime_format)
    orderwmode = mode.objects.filter(MODE = washing).values()
    wmodetime = int(orderwmode[0]['TIME'])
    orderlmode = mode.objects.filter(MODE = drying).values()
    lmodetime = int(orderlmode[0]['TIME'])
    wlmodetime = wmodetime+lmodetime   #洗烘所需時間
    orderftime = mode.objects.filter(MODE = fold1).values()
    fmodetime = int(orderftime[0]['TIME'])   #摺衣所需時間
    flmachin.objects.create(FMID = usefm, ORDID = newestid, TIME = fmodetime, FMODE = fold1)
    wlmachin.objects.create(WMID = usewm, ORDID = newestid, TIME = wlmodetime, WMODE = washing, LMODE = drying)

    

    # for data in haveorder:
    #     orderid = data['ORDID1']   #訂單編號
    #     wdmachine = data['WMID1']   #洗烘衣機編號
    #     fdmachine = data['FMID1']   #摺衣機編號
    #     locker = data['LOCKID1']   #鎖櫃編號
    #     bagid = data['BAGID1']   #洗衣袋編號
    #     handletime = data['HDATE1']   #所需時間
    #     wmode = data['WMODE1']   #洗衣模式
    #     lmode = data['LMODE1']   #乾燥模式
    #     fmode = data['FMODE1']   #摺衣模式
    #     intime = data['PFTIME1']   #放入鎖櫃時間
    #     lock.objects.create(LOCKID = locker, ORDID = orderid, INDATE = intime)
    #     orderwmode = mode.objects.filter(MODE = wmode).values()
    #     wmodetime = int(orderwmode[0]['TIME'])
    #     orderlmode = mode.objects.filter(MODE = lmode).values()
    #     lmodetime = int(orderlmode[0]['TIME'])
    #     wlmodetime = wmodetime+lmodetime   #洗烘所需時間
    #     orderftime = mode.objects.filter(MODE = fmode).values()
    #     fmodetime = int(orderftime[0]['TIME'])   #摺衣所需時間
    #     flmachin.objects.create(FMID = fdmachine, ORDID = orderid, TIME = fmodetime, FMODE = fmode)
    #     wlmachin.objects.create(WMID = wdmachine, ORDID = orderid, TIME = wlmodetime, WMODE = wmode, LMODE = lmode)


    return render(request, 'page/order_sent.html', locals())


def order_tracking(request):
    userid = "1"
    handlestate = "處理中"
    count=0
    tem=""
    show="no"
    ordernum = []
    handle = hstate.objects.filter(MEMID1 = userid).values()


    for data in handle:   #下方白色條
        tem="Slide "+str(count)
        everyorder = {"a1": count, "b1": tem}
        ordernum.append(everyorder)
        count+=1
    if count >= 2:
        show = "yes"

    
    if handle:
        for data in handle:
            ftime = handle[0]['PFTIME1']
            orderid = handle[0]['ORDID1']
            time = datetime.datetime.now()
            if time > ftime:
                hstate.objects.filter(MEMID1 = userid, ORDID1 = orderid).update(CLOTH1 = "已完成", COLSTATE1 = "可領取")





    return render(request, 'page/order_tracking1.html', locals())


def map(request):
    return render(request, 'page/map.html', locals())


def historical(request):
    return render(request, 'page/historical.html', locals())

def problemreturns(request):
    return render(request, 'page/problemreturns.html', locals())

def teaching(request):
    return render(request, 'page/teaching.html', locals())

def finish_confirmation(request):
    return render(request, 'page/finish_confirmation.html', locals())

def payment_confirmation(request):
    return render(request, 'page/payment_confirmation.html', locals())

